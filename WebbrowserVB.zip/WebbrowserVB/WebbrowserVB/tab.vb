﻿Public Class tab

    Private Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click

        AxWebBrowser1.Navigate(TextBox1.Text)

    End Sub

    Private Sub btnForward_Click(sender As Object, e As EventArgs) Handles btnForward.Click

        AxWebBrowser1.GoForward()

    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click

        AxWebBrowser1.GoBack()

    End Sub

    Private Sub AxWebBrowser1_NavigateComplete2(ByVal sender As Object, ByVal e As AxSHDocVw.DWebBrowserEvents2_NavigateComplete2Event) Handles AxWebBrowser1.NavigateComplete2

        Parent.Text = AxWebBrowser1.LocationName

    End Sub

    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click

        Dim t As New TabPage
        Dim newtab As New tab

        newtab.Show()
        newtab.TopLevel = False
        newtab.Dock = DockStyle.Fill
        t.Controls.Add(newtab)
        Form1.TabControl1.TabPages.Add(t)

    End Sub

    Private Sub btnCloseTab_Click(sender As Object, e As EventArgs) Handles btnCloseTab.Click

        If Form1.TabControl1.TabPages.Count = 1 Then

            Application.Exit()

        Else

            Form1.TabControl1.TabPages.Remove(Form1.TabControl1.SelectedTab)

        End If

    End Sub

End Class